## Verbos

APIs REST utilizam métodos do HTTP definindo a seguinte padronização para cada ação:
- POST - usado para criar recursos
- GET - para ler recursos
- PUT - usado para atualizar um recurso existente
- PATCH =~ PUT
- DELETE - deletar um recurso

Estes métodos são também chamados de verbos o qual podemos associar com as operações CRUD: 
- create (POST)
- read (GET)
- update (PUT and PATCH)
- delete (DELETE)

Mais raramente usados o REST também usa:
- OPTIONS: obter as opções de comunicação request/response disponíveis.
- HEAD: obtém o header do response (desconsiderando o body)