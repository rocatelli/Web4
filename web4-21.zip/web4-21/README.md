# Desenvolvimento Web IV
- Curso: TADS
- Semestre: 2021/2
- [Moodle](https://ava.ifpr.edu.br/course/view.php?id=6531)

## Material
- [templates view cineclube](https://gist.github.com/fscheidt/9e238f1b4bb070419412e5157a5ff95e)


## tools
- [code share](https://docs.google.com/document/d/1flNJXGXJx-rWbj9rgwYNP553U1mCd9jKpsGeOloRRAY/edit)

---

`42541e9f-d456-472c-b124-eb066ba6fd9c`

