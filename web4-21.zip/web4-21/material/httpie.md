# Httpie

- https://httpie.io/
- https://pie.dev 

Httpie é uma ferramenta para teste de api Rest

Install
`sudo apt-get install httpie`

## GET request/response

**Request**

body:

```
http GET https://github.com -p B
```

Header:

```
http GET https://github.com -p H
```


**Response**

```
http GET https://github.com -p h
```

```
http GET https://github.com -p b
```

```
http GET https://foz.ifpr.edu.br/ -p h 
```
ou
```
http GET https://foz.ifpr.edu.br/ -h
```


```
http GET https://pie.dev/get -p h
```

```
http GET https://pie.dev/get -p b
```

```
http GET https://pie.dev/status/500
```

```
http -f POST pie.dev/post name=jose city="sao paulo"
```

```
http https://api.github.com/search/repositories q==vim per_page==1
```

# Implementar no cineclube

## GET
```
http :8080/api/pessoa/1
```

```
http :8080/api/pessoas
```

## POST
```
http :8080/api/pessoa < pessoa.json
```
 
 ## PUT  (update)
 ```
 http PUT :8080/api/pessoa/4 < updatePessoaId4.json
 ```
 (se pessoa id=4 existe entao faz update)
 
 ## PUT (add)
 ```
 http PUT :8080/api/pessoa/111 < updateOrAdd.json
 ```
 (id 111 não existe entao nesse caso adiciona)
 
 ## DELETE
 ```
 http DELETE :8080/api/pessoa/1
 ```


