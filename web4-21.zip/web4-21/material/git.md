# Criar repositório

```
git init

git add -A

git commit -m "alguma mensagem"

# so faz na primeira vez
git remote add origin https://github.com/nome/projeto

# sobe as mudanças locais para o github.
git push origin master

```

# Manutenção (sincronizar mudanças locais)
```
git add -A
git commit -m ""
git push origin master
```


# Clonar

Faz a copia do projeto para a maquina
```
`git clone https://github.com/fscheidt/web4-21`

# Atualiza

git pull origin master

cd /web4-21/cineclube
```


# Como importar no spring tools??

```
File > Import > Existing maven project
Seleciona o diretorio do projeto
Finish
```









