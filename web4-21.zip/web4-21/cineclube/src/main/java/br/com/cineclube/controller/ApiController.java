package br.com.cineclube.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.cineclube.dao.FilmeRepository;
import br.com.cineclube.dao.PessoaRepository;
import br.com.cineclube.model.Filme;
import br.com.cineclube.model.Pessoa;

@RestController
@RequestMapping("/api")
public class ApiController {
	
	@Autowired
	private FilmeRepository dao;
	
	@Autowired
	private PessoaRepository daoPessoa;
	
	@GetMapping("/pessoa/{id}")
	Optional<Pessoa> getPessoa(@PathVariable Long id) {
	return daoPessoa.findById(id);
	}
	
	@GetMapping("/pessoas")
	Iterable<Pessoa> gePessoas() {
	return daoPessoa.findAll();
	}
	
	@PostMapping("/pessoa")
	Pessoa postPessoa(@RequestBody Pessoa pessoa) {
	daoPessoa.save(pessoa);
	return pessoa;
	}
	
	@DeleteMapping("/pessoa/{id}")
	void deletePessoa(@PathVariable Long id) {
	daoPessoa.deleteById(id);
	}
	
	// http://localhost:8080/api/filme/3
	@GetMapping("/api/filme/{id}")
	public Filme getFilme(@PathVariable Long id) {
		return dao.getById(id);
	}
	
	
	/*
	 * @GetMapping("/api/person/get/{id}") public Pessoa getPessoa(@PathVariable
	 * Long id) { Pessoa p = daoPessoa.findById(id).get(); return p; }
	 */

	
	
	
//	@GetMapping("/api/person/new/{name}")
//	public Person newPerson(@PathVariable String name) {
//		Person p = new Person(name);
//		daoPerson.save(p);
//		return p;		
//	}
	
	

}
